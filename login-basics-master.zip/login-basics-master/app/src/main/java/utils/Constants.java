package utils;

/**
 * Created by AndreBTS on 25/09/2015.
 */
public class Constants {
    public static final String TAG_EMAIL = "email";
    public static final String TAG_LOGIN = "login";

}
